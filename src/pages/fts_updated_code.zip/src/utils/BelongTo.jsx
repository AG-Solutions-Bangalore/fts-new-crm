const belongs_to = [
    "Executive Committee",
    "Mahila Samiti",
    "Ekal Yuva",
    "Functional Committee",
  ];
  export default belongs_to ;